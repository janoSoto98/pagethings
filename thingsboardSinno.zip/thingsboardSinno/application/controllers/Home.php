<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

public function __construct() {
		parent::__construct();

		// Load form helper library
		$this->load->helper('form');

		// Load form validation library
		$this->load->library('form_validation');

		// Load session library
		$this->load->library('session');
		$this->load->model('m_device');
		$this->load->model('m_tskv');
		$this->load->model('m_tbUser');
	}
	

	
	public function index()
	{
		$this->load->view('login/login');
	}
	public function panel()
	{
		$checar=$this->session->userdata('username'); 
		if ($checar=="") {
    		redirect("");
		}
		$this->load->view('admin/Helpers/header');

    	$nameDevice= $this->uri->segment(3);
		$valor_query1=$this->m_device->getDeviceId($nameDevice);
		$idDevice=$valor_query1;

			$data['dateIni']= "";
			$data['dateFin']="";
			$this->input->post('txt_dateIni');
		if (!is_null($this->input->post('txt_dateIni'))) {
			# code...;
			$dateIni=$this->input->post('txt_dateIni');
			$dateFin=$this->input->post('txt_datefin');
			$data['dateIni']= $dateIni;
			$data['dateFin']=$dateFin;
    		
    		$date1 = str_replace('/"', '-', $dateIni);  
    		$date2 = str_replace('/"', '-', $dateFin);  
    		$newDate1 = date("Y-m-d", strtotime($date1));  
    		$newDate2 = date("Y-m-d", strtotime($date2));  
			$valor_query2=$this->m_tskv->getMinMaxAvg_perLine($newDate1,$newDate2,$nameDevice);
			$valor_query3=$this->m_tskv->getVolt($newDate1,$newDate2,$nameDevice);
			$valor_query4=$this->m_tskv->getCurrent($newDate1,$newDate2,$nameDevice);
			$valor_query5=$this->m_tskv->getPower_l($newDate1,$newDate2,$nameDevice);
			$power=$this->m_tskv->getPower($newDate1,$newDate2,$nameDevice);
			$Kvarh=$this->m_tskv->getKvarh($newDate1,$newDate2,$nameDevice);

			$data['dataQuery']=$valor_query2;
			$data['Kvarh']=$Kvarh;
			$data['power']=$power/1000;
			$data['dataQuery_Volt']=$valor_query3;
			$data['dataQuery_Current']=$valor_query4;
			$data['dataQuery_Power_l']=$valor_query5;
		}
		$data['nameDevice']= $nameDevice;
		$data['idDevice']=$idDevice;


		$this->load->view('admin/panel',$data);
		$this->load->view('admin/Helpers/footer');
	}
	public function panelData()
	{
		$checar=$this->session->userdata('username'); 
		if ($checar=="") {
    		redirect("");
		}
        $data['arr'] = array("data" => $valor_query2);
		$this->load->view('admin/Helpers/header');
		$this->load->view('admin/panel',$data);
		$valor_query2=$this->m_tskv->getMinMaxAvg_perLine();
		
		$this->load->view('admin/Helpers/footer');
	}

	public function device()
	{
		$checar=$this->session->userdata('username'); 
		if ($checar=="") {
    		redirect("");
		}
		$this->load->view('admin/Helpers/header');

		$checar=$this->session->userdata('username');
		$valor_query=$this->m_tbUser->getCustomerId($checar);
		$valor_query2=$this->m_device->getDevice($valor_query);

        $data = array("data" => $valor_query2);

		$this->load->view('admin/index', $data);
		$this->load->view('admin/Helpers/footer');
	}

	public function process()
	{
		$payload = [
		            'username'=> $this->input->post('email'), 
		            'password'=>  $this->input->post('psw')
		        ];
        $url = 'http://25.53.101.58:8080/api/auth/login';
        $ch  = curl_init($url);

		// Attach encoded JSON string to the POST fields
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
		// Set the content type to application/json
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		   
		// Return response instead of outputting
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		// Execute the POST request
		$result = curl_exec($ch);
		curl_close($ch);
		$username= $this->input->post('email');
		$data = json_decode($result);
		if (!isset($data->token)) {
            $sal['error'] = 'Tu usuario es incorrecto';
			$this->load->view('login/login',$sal);
		}else{
    		$this->session->set_userdata(array('username'=>$username));  
    		redirect("/Home/device");
		}
	}
	 public function logout()  
    {  
        //removing session  
        $this->session->unset_userdata('username'); 
        redirect("");  
    }

   
}
