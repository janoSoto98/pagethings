 <div id="pdfPrin">
    <div class="container">
             
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"></h1>
                <?php if (isset($power)) {?>
                <button class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" onclick="formtoPDF()"><i class="fas fa-download fa-sm text-white-50" ></i> Generar Reporte</button>

                <?php } ?>
        </div>
        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                    <div class="" id='pdfPrint1'>
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Reporte de Operación</h1>
                            </div>
                            <form class="user" method="post" action="<?php echo base_url(); ?>index.php/home/panel/<?=$nameDevice?>">
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <label class="text-gray-900">Medidor</label>
                                        <input type="text" class="form-control form-control-user" id="txt_name" value="<?=$nameDevice?>" disabled="" name="txt_name"   placeholder="Name Device">
                                    </div>
                                 <!--   <div class="col-sm-6">
                                        <input type="text" class="form-control form-control-user" value="<?=$idDevice?>" disabled="" id="txt_id" name="txt_id" placeholder="ID">
                                    </div>-->
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <label class="text-gray-900">Fecha Inicio:</label>
                                        <?php if (is_null($dateIni)) {
                                            # code...?>
                                            <input type="date" class="form-control form-control-user" id="txt_dateIni" name="txt_dateIni" placeholder="DD/MM/YYYY" onkeypress="return false" >
                                        <?php }else{?>
                                            <input type="date" class="form-control form-control-user" id="txt_dateIni" name="txt_dateIni"  placeholder="DD/MM/YYYY" value="<?=$dateIni?>"  onkeypress="return false" >
                                              <?php }?>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="text-gray-900">Fecha Fin :</label>
                                        <?php if (is_null($dateFin)) {
                                            # code...?>
                                            <input type="date" class="form-control form-control-user" id="txt_datefin" name="txt_datefin" placeholder="DD/MM/YYYY" onkeypress="return false" >
                                        <?php }else{?>
                                            <input type="date" class="form-control form-control-user" id="txt_datefin" name="txt_datefin"  placeholder="DD/MM/YYYY" value="<?=$dateFin ?>"  onkeypress="return false" >
                                              <?php }?>
                                    </div>
                                </div>
                                <input  class="btn btn-primary btn-user btn-block" value="Aceptar" type="submit">
                                
                            </form>

                        </div>
                    </div>

        <div id="editor"></div>
            </div>
        </div>



    </div>

    <div class="container-fluid" >
         <!-- Content Row -->
                    <div class="row" id="pdfPrint2">

                        <?php if (isset($power)) {?>
                            <!-- Earnings (Monthly) Card Example -->
                            <div class="nav-link col-xl-3 col-md-6 mb-4" >
                                <div class="card border-left-danger shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-primary text mb-1">Consumo (KW/h)</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo round($power,2)?></div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-atom fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>

                        <?php if (isset($Kvarh)) {?>
                            <!-- Earnings (Monthly) Card Example -->
                            <div class="nav-link col-xl-3 col-md-6 mb-4" >
                                <div class="card border-left-warning shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-primary text mb-1">Consumo (KVarh)</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo round(($Kvarh/1000),2) ?></div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-atom fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="row">

                        <!-- Content Column -->
                        <div class="col-lg-6 mb-4">

                            <!-- Project Card Example -->
                            <?php if (isset($dataQuery)) { ?>
                        
                            <div class="card shadow mb-4" id="pdfPrint3">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Factor de potencia</h6>
                                </div>
                                <div class="card-body">
                                    
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">Linea</th>
                                                <th scope="col">Mínimo</th>
                                                <th scope="col">Máximo</th>
                                                <th scope="col">Promedio</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php  $x=1;
                                            foreach($dataQuery as $dataQuery){ ?>
                                                <tr>
                                                    <th scope="row"><?php echo "L".$x ?></th>
                                                    <td><?php echo $dataQuery->min ?></td>
                                                    <td><?php echo $dataQuery->max ?></td>
                                                    <td><?php echo round($dataQuery->avg,2) ?></td>
                                                </tr>
                                            <?php  $x++;}?>
                                        </tbody>
                                    </table>
                
                                </div>
                            </div>
                             <?php } ?>
                        </div>
                        <div class="col-lg-6 mb-4">

                            <!-- Project Card Example -->
                            <?php if (isset($dataQuery_Volt)) { ?>
                        
                            <div class="card shadow mb-4" id="pdfPrint4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Voltaje Linea a Linea (V)</h6>
                                </div>
                                <div class="card-body">
                                    
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">Linea</th>
                                                <th scope="col">Mínimo</th>
                                                <th scope="col">Máximo</th>
                                                <th scope="col">Promedio</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php $x1=1; foreach($dataQuery_Volt as $dataQuery_Volt){ ?>
                                                <tr>
                                                    <th scope="row"><?php echo "L".($x1)."-"."L".($x1+1 == 4 ? "1":($x1+1)) ?></th>
                                                    <td><?php echo $dataQuery_Volt->min ?></td>
                                                    <td><?php echo $dataQuery_Volt->max ?></td>
                                                    <td><?php echo round($dataQuery_Volt->avg,2) ?></td>
                                                </tr>
                                            <?php $x1++;}?>
                                        </tbody>
                                    </table>
                
                                </div>
                            </div>
                             <?php } ?>
                        </div>
                         <div class="col-lg-6 mb-4">

                            <!-- Project Card Example -->
                            <?php if (isset($dataQuery_Current)) { ?>
                        
                            <div class="card shadow mb-4" id="pdfPrint5">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Corriente (A)</h6>
                                </div>
                                <div class="card-body">
                                    
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">Linea</th>
                                                <th scope="col">Mínimo</th>
                                                <th scope="col">Máximo</th>
                                                <th scope="col">Promedio</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php $x2=1; foreach($dataQuery_Current as $dataQuery_Current){ ?>
                                                <tr>
                                                    <th scope="row"><?php echo "L".$x2 ?></th>
                                                    <td><?php echo $dataQuery_Current->min ?></td>
                                                    <td><?php echo $dataQuery_Current->max ?></td>
                                                    <td><?php echo round($dataQuery_Current->avg,2) ?></td>
                                                </tr>
                                            <?php $x2++;}?>
                                        </tbody>
                                    </table>
                
                                </div>
                            </div>
                             <?php } ?>
                        </div>
                         <div class="col-lg-6 mb-4">

                            <!-- Project Card Example -->
                            <?php if (isset($dataQuery_Power_l)) { ?>
                        
                            <div class="card shadow mb-4" id="pdfPrint6">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Potencia (KW)</h6>
                                </div>
                                <div class="card-body">
                                    
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">Linea</th>
                                                <th scope="col">Mínimo</th>
                                                <th scope="col">Máximo</th>
                                                <th scope="col">Promedio</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php $x3=1; foreach($dataQuery_Power_l as $dataQuery_Power_l){ ?>
                                                <tr>
                                                    <th scope="row"><?php echo "L".$x3 ?></th>
                                                    <td><?php echo $dataQuery_Power_l->min ?></td>
                                                    <td><?php echo $dataQuery_Power_l->max ?></td>
                                                    <td><?php echo round(($dataQuery_Power_l->avg/1000),2) ?></td>
                                                </tr>
                                            <?php $x3++; }?>
                                        </tbody>
                                    </table>
                
                                </div>
                            </div>
                             <?php } ?>
                        </div>
                    </div>
                </div>
</div>

<script>
function loadImage(url) {
  return new Promise((resolve) => {
    let img = new Image();
    img.onload = () => resolve(img);
    img.src = url;
  })
}
function formtoPDF() {
  /*  var quotes = document.getElementById('pdfPrint2');
       html2canvas(quotes)
      .then((canvas) => {
            //! MAKE YOUR PDF
            var pdf = new jsPDF('p', 'pt', 'letter');

            for (var i = 0; i <= quotes.clientHeight/980; i++) {
                //! This is all just html2canvas stuff
                var srcImg  = canvas;
                var sX      = 0;
                var sY      = 980*i; // start 980 pixels down for every new page
                var sWidth  = 900;
                var sHeight = 980;
                var dX      = 0;
                var dY      = 0;
                var dWidth  = 900;
                var dHeight = 980;

                window.onePageCanvas = document.createElement("canvas");
                onePageCanvas.setAttribute('width', 900);
                onePageCanvas.setAttribute('height', 980);
                var ctx = onePageCanvas.getContext('2d');
                // details on this usage of this function: 
                // https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Using_images#Slicing
                ctx.drawImage(srcImg,sX,sY,sWidth,sHeight,dX,dY,dWidth,dHeight);

                // document.body.appendChild(canvas);
                var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);

                var width         = onePageCanvas.width;
                var height        = onePageCanvas.clientHeight;

                //! If we're on anything other than the first page,
                // add another page
                if (i > 0) {
                    pdf.addPage(612, 791); //8.5" x 11" in pts (in*72)
                }
                //! now we declare that we're working on that page
                pdf.setPage(i+1);
                //! now we add content to that page!
                pdf.addImage(canvasDataURL, 'PNG', 20, 40, (width*.62), (height*.62));

            }
            //! after the for loop is finished running, we save the pdf.
            pdf.save('Test.pdf');
        
      });*/
    var base_url = '<?php echo base_url() ?>';
            var pdfBlock = new jsPDF('l', 'pt', 'a4');

       var quotes = document.getElementById('pdfPrint1');
       html2canvas(quotes)
      .then((canvas) => {
            //! MAKE YOUR PDF
            for (var i = 0; i <= quotes.clientHeight/980; i++) {
                //! This is all just html2canvas stuff
                var srcImg  = canvas;
                var sX      = 0;
                var sY      = 980*i; // start 980 pixels down for every new page
                var sWidth  = 1200;
                var sHeight = 980;
                var dX      = 0;
                var dY      = 100;
                var dWidth  = 1200;
                var dHeight = 980;

                window.onePageCanvas = document.createElement("canvas");
                onePageCanvas.setAttribute('width', 1200);
                onePageCanvas.setAttribute('height', 980);
                var ctx = onePageCanvas.getContext('2d');
                // details on this usage of this function: 
                ctx.drawImage(srcImg,sX,sY,sWidth,sHeight,dX,dY,dWidth,dHeight);
                // document.body.appendChild(canvas);
                var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);

                var width         = onePageCanvas.width;
                var height        = onePageCanvas.clientHeight;

                //! If we're on anything other than the first page,
                // add another page
              
                //! now we declare that we're working on that page
                pdfBlock.setPage(i+1);
                //! now we add content to that page!
                pdfBlock.addImage(canvasDataURL, 'PNG', 100,40, (width*.65), (height*.65));

            }
            //! after the for loop is finished running, we save the pdf.
        
      });


        var quotes = document.getElementById('pdfPrint2');
         hg=341;
       html2canvas(quotes)
      .then((canvas) => {
            //! MAKE YOUR PDF
            for (var i = 0; i <= quotes.clientHeight/980; i++) {
                //! This is all just html2canvas stuff
                var srcImg  = canvas;
                var sX      = 0;
                var sY      = 980*i; // start 980 pixels down for every new page
                var sWidth  = 900;
                var sHeight = 980;
                var dX      = 0;
                var dY      = 550;
                var dWidth  = 900;
                var dHeight = 980;

                window.onePageCanvas = document.createElement("canvas");
                onePageCanvas.setAttribute('width', 900);
                onePageCanvas.setAttribute('height', 980);
                var ctx = onePageCanvas.getContext('2d');
                // details on this usage of this function: 
                // https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Using_images#Slicing
                ctx.drawImage(srcImg,sX,sY,sWidth,sHeight,dX,dY,dWidth,dHeight);
                // document.body.appendChild(canvas);
                var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);

                var width         = onePageCanvas.width;
                var height        = onePageCanvas.clientHeight;

                //! If we're on anything other than the first page,
                // add another page
                if (i > 0) {
                    pdfBlock.addPage(612, 791); //8.5" x 11" in pts (in*72)
                }
                //! now we declare that we're working on that page
                pdfBlock.setPage(i+1);
                //! now we add content to that page!
                pdfBlock.addImage(canvasDataURL, 'PNG', 25, 40, (width*.65), (height*.65));

            }
            //! after the for loop is finished running, we save the pdf.
        
      });

        loadImage(base_url+'assets/imagenes/local.png').then((logo) => {
                        pdfBlock.setPage(1);
          pdfBlock.addImage(logo, 'PNG', 720, 5,205*.40,246*.40);
        });
      quotes = document.getElementById('pdfPrint3');
       html2canvas(quotes)
      .then((canvas) => {
            //! MAKE YOUR PDF
            for (var i = 0; i <= quotes.clientHeight/980; i++) {
                //! This is all just html2canvas stuff
                var srcImg  = canvas;
                var sX      = 0;
                var sY      = 980*i; // start 980 pixels down for every new page
                var sWidth  = 900;
                var sHeight = 980;
                var dX      = 0;
                var dY      = 0;
                var dWidth  = 900;
                var dHeight = 980;

                window.onePageCanvas = document.createElement("canvas");
                onePageCanvas.setAttribute('width', 900);
                onePageCanvas.setAttribute('height', 980);
                var ctx = onePageCanvas.getContext('2d');
                // details on this usage of this function: 
                // https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Using_images#Slicing
                ctx.drawImage(srcImg,sX,sY,sWidth,sHeight,dX,dY,dWidth,dHeight);
                // document.body.appendChild(canvas);
                var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);

                var width         = onePageCanvas.width;
                var height        = onePageCanvas.clientHeight;

                //! If we're on anything other than the first page,
                // add another page
                pdfBlock.addPage(); //8.5" x 11" in pts (in*72)
            
                //! now we declare that we're working on that page
                pdfBlock.setPage(2);
                //! now we add content to that page!
                pdfBlock.addImage(canvasDataURL, 'PNG', 20, 40, (width*.65), (height*.65));
            }
            //! after the for loop is finished running, we save the pdf.
        
      });
    
    hg=hg+300;
      quotes = document.getElementById('pdfPrint4');
       html2canvas(quotes)
      .then((canvas) => {
            //! MAKE YOUR PDF
            for (var i = 0; i <= quotes.clientHeight/980; i++) {
                //! This is all just html2canvas stuff
                var srcImg  = canvas;
                var sX      = 0;
                var sY      = 980*i; // start 980 pixels down for every new page
                var sWidth  = 900;
                var sHeight = 980;
                var dX      = 0;
                var dY      = 350;
                var dWidth  = 900;
                var dHeight = 980;

                window.onePageCanvas = document.createElement("canvas");
                onePageCanvas.setAttribute('width', 900);
                onePageCanvas.setAttribute('height', 980);
                var ctx = onePageCanvas.getContext('2d');
                // details on this usage of this function: 
                // https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Using_images#Slicing
                ctx.drawImage(srcImg,sX,sY,sWidth,sHeight,dX,dY,dWidth,dHeight);
                // document.body.appendChild(canvas);
                var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);

                var width         = onePageCanvas.width;
                var height        = onePageCanvas.clientHeight;

                //! If we're on anything other than the first page,
                // add another page
            
                //! now we declare that we're working on that page
                pdfBlock.setPage(2);
                //! now we add content to that page!
                pdfBlock.addImage(canvasDataURL, 'PNG', 20, 40, (width*.65), (height*.65));


            }
            //! after the for loop is finished running, we save the pdf.
        
      });
      
      quotes = document.getElementById('pdfPrint5');
       html2canvas(quotes)
      .then((canvas) => {
            //! MAKE YOUR PDF
            for (var i = 0; i <= quotes.clientHeight/980; i++) {
                //! This is all just html2canvas stuff
                var srcImg  = canvas;
                var sX      = 0;
                var sY      = 980*i; // start 980 pixels down for every new page
                var sWidth  = 900;
                var sHeight = 980;
                var dX      = 0;
                var dY      = 0;
                var dWidth  = 900;
                var dHeight = 980;

                window.onePageCanvas = document.createElement("canvas");
                onePageCanvas.setAttribute('width', 900);
                onePageCanvas.setAttribute('height', 980);
                var ctx = onePageCanvas.getContext('2d');
                // details on this usage of this function: 
                // https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Using_images#Slicing
                ctx.drawImage(srcImg,sX,sY,sWidth,sHeight,dX,dY,dWidth,dHeight);
                // document.body.appendChild(canvas);
                var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);

                var width         = onePageCanvas.width;
                var height        = onePageCanvas.clientHeight;

                //! If we're on anything other than the first page,
                // add another page
                
                pdfBlock.addPage(); //8.5" x 11" in pts (in*72)
                //! now we declare that we're working on that page
                pdfBlock.setPage(3);
                //! now we add content to that page!
                pdfBlock.addImage(canvasDataURL, 'PNG', 20, 40, (width*.65), (height*.65));

            }
            //! after the for loop is finished running, we save the pdf.
        
      });
      quotes = document.getElementById('pdfPrint6');
       html2canvas(quotes)
      .then((canvas) => {
            //! MAKE YOUR PDF
            for (var i = 0; i <= quotes.clientHeight/980; i++) {
                //! This is all just html2canvas stuff
                var srcImg  = canvas;
                var sX      = 0;
                var sY      = 980*i; // start 980 pixels down for every new page
                var sWidth  = 900;
                var sHeight = 980;
                var dX      = 0;
                var dY      = 350;
                var dWidth  = 900;
                var dHeight = 980;

                window.onePageCanvas = document.createElement("canvas");
                onePageCanvas.setAttribute('width', 900);
                onePageCanvas.setAttribute('height', 980);
                var ctx = onePageCanvas.getContext('2d');

                ctx.drawImage(srcImg,sX,sY,sWidth,sHeight,dX,dY,dWidth,dHeight);
                // document.body.appendChild(canvas);
                var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);

                var width         = onePageCanvas.width;
                var height        = onePageCanvas.clientHeight;

               
                //! now we declare that we're working on that page
                pdfBlock.setPage(3);
                //! now we add content to that page!
                pdfBlock.addImage(canvasDataURL, 'PNG', 20, 40, (width*.65), (height*.65));
                pdfBlock.save('reporte.pdf');

            }
            //! after the for loop is finished running, we save the pdf.
        
      });
}
</script>
