<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class m_tskv extends CI_Model {
	function __construct(){
        parent::__construct();
        $this->load->database();
    }
    public function getMinMaxAvg_perLine($date1,$date2,$name){
			$query  = "SELECT ts_kv_dictionary.key,MIN(ts_kv.dbl_v) as min,MAX(ts_kv.dbl_v) as max,AVG(ts_kv.dbl_v) as avg FROM ts_kv INNER Join ts_kv_dictionary ON ts_kv.key = ts_kv_dictionary.key_id INNER Join device ON ts_kv.entity_id = device.id INNER JOIN attribute_kv on attribute_kv.entity_id = ts_kv.entity_id WHERE ((device.name='".$name."' AND (ts_kv_dictionary.key='PF_L1' or ts_kv_dictionary.key='PF_L2'  OR ts_kv_dictionary.key='PF_L3'))) AND (to_timestamp(ts_kv.ts/1000)::timestamp AT TIME ZONE 'UTC' >='".$date1."'::timestamp AT TIME ZONE attribute_kv.str_v AND to_timestamp(ts_kv.ts/1000)::timestamp AT TIME ZONE 'UTC' >='".$date2."'::timestamp AT TIME ZONE attribute_kv.str_v)  AND (device.name='".$name."' and (ts_kv_dictionary.key='PF_L1' OR  ts_kv_dictionary.key='PF_L2' OR ts_kv_dictionary.key='PF_L3' )) GROUP BY ts_kv_dictionary.key;";

    		$resultado = $this->db->query($query);
    		$result = $resultado->result();
            return $result;
    }
     public function getPower($date1,$date2,$name){
            $query  = "SELECT ts_kv_dictionary.key, MAX(ts_kv.long_v)-MIN(ts_kv.long_v) as datavalue FROM ts_kv INNER Join ts_kv_dictionary ON ts_kv.key = ts_kv_dictionary.key_id INNER Join device ON ts_kv.entity_id = device.id INNER JOIN attribute_kv on attribute_kv.entity_id = ts_kv.entity_id WHERE ((device.name='".$name."' AND (ts_kv_dictionary.key='KWh_Total'))) AND (to_timestamp(ts_kv.ts/1000)::timestamp AT TIME ZONE 'UTC' >='".$date1."'::timestamp AT TIME ZONE attribute_kv.str_v AND to_timestamp(ts_kv.ts/1000)::timestamp AT TIME ZONE 'UTC' >='".$date2."'::timestamp AT TIME ZONE attribute_kv.str_v) GROUP BY  ts_kv_dictionary.key;";

            $query = $this->db->query($query);

            $resultado = $query->row();

            if ($query->num_rows() == 1) {
                return $resultado->datavalue;
        }
    }
     public function getVolt($date1,$date2,$name){
            $query  = "SELECT ts_kv_dictionary.key, MAX(ts_kv.dbl_v),MIN(ts_kv.dbl_v), AVG(ts_kv.dbl_v) FROM ts_kv INNER Join ts_kv_dictionary ON ts_kv.key = ts_kv_dictionary.key_id INNER Join device ON ts_kv.entity_id = device.id INNER JOIN attribute_kv on attribute_kv.entity_id = ts_kv.entity_id WHERE (device.name='".$name."' AND (ts_kv_dictionary.key='VOLT_L1L2' or ts_kv_dictionary.key='VOLT_L2L3' or ts_kv_dictionary.key='VOLT_L3L1' )) AND (to_timestamp(ts_kv.ts/1000)::timestamp AT TIME ZONE 'UTC' >='".$date1."'::timestamp AT TIME ZONE attribute_kv.str_v  - interval '1' day AND to_timestamp(ts_kv.ts/1000)::timestamp AT TIME ZONE 'UTC' >='".$date2."'::timestamp AT TIME ZONE attribute_kv.str_v) GROUP BY  ts_kv_dictionary.key;";

            $resultado = $this->db->query($query);
            $result = $resultado->result();
            return $result;
    }
     public function getCurrent($date1,$date2,$name){
            $query  = "SELECT ts_kv_dictionary.key, MAX(ts_kv.dbl_v),MIN(ts_kv.dbl_v), AVG(ts_kv.dbl_v) FROM ts_kv INNER Join ts_kv_dictionary ON ts_kv.key = ts_kv_dictionary.key_id  INNER Join device ON ts_kv.entity_id = device.id  INNER JOIN attribute_kv on attribute_kv.entity_id = ts_kv.entity_id WHERE (device.name='".$name."' AND (ts_kv_dictionary.key='CURR_L1' or ts_kv_dictionary.key='CURR_L2' or ts_kv_dictionary.key='CURR_L3' ))  AND (to_timestamp(ts_kv.ts/1000)::timestamp AT TIME ZONE 'UTC' >='".$date1."'::timestamp AT TIME ZONE attribute_kv.str_v - interval '1' day AND to_timestamp(ts_kv.ts/1000)::timestamp AT TIME ZONE 'UTC' >='".$date2."'::timestamp AT TIME ZONE attribute_kv.str_v ) GROUP BY  ts_kv_dictionary.key;";

            $resultado = $this->db->query($query);
            $result = $resultado->result();
            return $result;
    }
     public function getPower_l($date1,$date2,$name){
            $query  = "SELECT ts_kv_dictionary.key, MIN(ts_kv.dbl_v), MAX(ts_kv.dbl_v),AVG(ts_kv.dbl_v) FROM ts_kv INNER Join ts_kv_dictionary ON ts_kv.key = ts_kv_dictionary.key_id INNER Join device ON ts_kv.entity_id = device.id INNER JOIN attribute_kv on attribute_kv.entity_id = ts_kv.entity_id WHERE (device.name='".$name."' AND (ts_kv_dictionary.key='POW_L1' or ts_kv_dictionary.key='POW_L2' or ts_kv_dictionary.key='POW_L3' )) AND (to_timestamp(ts_kv.ts/1000)::timestamp AT TIME ZONE 'UTC' >='".$date1."'::timestamp AT TIME ZONE attribute_kv.str_v  - interval '1' day AND to_timestamp(ts_kv.ts/1000)::timestamp AT TIME ZONE 'UTC' >='".$date2."'::timestamp AT TIME ZONE attribute_kv.str_v ) GROUP BY  ts_kv_dictionary.key;";

            $resultado = $this->db->query($query);
            $result = $resultado->result();
            return $result;
    }
     public function getKvarh($date1,$date2,$name){
            $query  = "SELECT ts_kv_dictionary.key, MAX(ts_kv.long_v)-MIN(ts_kv.long_v) as datavalue FROM ts_kv INNER Join ts_kv_dictionary ON ts_kv.key = ts_kv_dictionary.key_id INNER Join device ON ts_kv.entity_id = device.id INNER JOIN attribute_kv on attribute_kv.entity_id = ts_kv.entity_id  WHERE ((device.name='".$name."' AND (ts_kv_dictionary.key='KVarh_Total'))) AND (to_timestamp(ts_kv.ts/1000)::timestamp AT TIME ZONE 'UTC' >='".$date1."'::timestamp AT TIME ZONE attribute_kv.str_v AND to_timestamp(ts_kv.ts/1000)::timestamp AT TIME ZONE 'UTC' >='".$date2."'::timestamp AT TIME ZONE attribute_kv.str_v ) GROUP BY  ts_kv_dictionary.key;";

            $query = $this->db->query($query);

            $resultado = $query->row();

            if ($query->num_rows() == 1) {
                return $resultado->datavalue;
        }
    }

}



