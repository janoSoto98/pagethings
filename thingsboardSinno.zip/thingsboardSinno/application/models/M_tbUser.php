
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class m_tbUser extends CI_Model {
	function __construct(){
        parent::__construct();
        $this->load->database();
    }
    public function getCustomerId($data){
    	$condition = "email ="."'".$data."'";
    	$this->db->select('customer_id');
		$this->db->from('tb_user');
		$this->db->where($condition);
		$this->db->limit(1);
		$query = $this->db->get();
		$resultado = $query->row();

		if ($query->num_rows() == 1) {
			return $resultado->customer_id;
		}
    }
}

